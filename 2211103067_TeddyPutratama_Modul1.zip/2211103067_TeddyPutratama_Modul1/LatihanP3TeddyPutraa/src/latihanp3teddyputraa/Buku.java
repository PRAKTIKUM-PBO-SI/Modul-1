/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package latihanp3teddyputraa;

/**
 *
 * @author Teddy Putratama
 * 2211103067
 * 07c
 */
public class Buku {
    String judul, penulis;
    int tahunTerbit;
    
    public Buku(String judul,String penulis, int tahunTerbit){
        this.judul = judul;
        this.penulis = penulis;
        this.tahunTerbit = tahunTerbit;
    }
    
}
