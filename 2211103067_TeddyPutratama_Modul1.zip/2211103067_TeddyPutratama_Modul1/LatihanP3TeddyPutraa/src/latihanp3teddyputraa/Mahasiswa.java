/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package latihanp3teddyputraa;

/**
 *
 * @author Teddy Putratama
 * 2211103067
 * 07C
 */
public class Mahasiswa {
    String nama;
    String nimMahasiswa;
    
    public Mahasiswa (String nama, String nimMahasiswa){
    this.nama = nama;
    this.nimMahasiswa = nimMahasiswa;
    }
}
 