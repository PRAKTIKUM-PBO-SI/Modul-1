/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package latihanp3teddyputraa;

/**
 *
 * @author Teddy Putratama
 * 2211103067
 * 07C
 */
public class LatihanP3TeddyPutraa {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Buku buku = new Buku("buku PPBO", "tendi", 2010);
        Mahasiswa mahasiswa = new Mahasiswa("teddyPutraa ", "2211103067");
        Peminjaman peminjaman = new Peminjaman (buku, mahasiswa, " 07/10/2024");
        
        peminjaman.tampilkanPeminjaman();
        peminjaman.kembalikanBuku("10/10/2024");
    }
    
}
